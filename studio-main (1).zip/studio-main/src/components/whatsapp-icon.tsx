
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { supabase } from '@/lib/supabase';
import { Skeleton } from './ui/skeleton';

export function WhatsAppIcon() {
  const [contactInfo, setContactInfo] = useState<{ phone_number: string | null }>({ phone_number: null });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchContactInfo = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('contact_info')
          .select('phone_number')
          .eq('id', 1)
          .single();

        if (error) throw error;
        
        if (data) {
          setContactInfo(data);
        }
      } catch (error) {
        console.error("Failed to fetch WhatsApp contact info:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchContactInfo();
  }, []);

  if (isLoading) {
    return <Skeleton className="fixed bottom-6 right-6 h-16 w-16 rounded-full" />;
  }
  
  if (!contactInfo.phone_number) {
    return null;
  }

  const whatsappLink = `https://wa.me/${contactInfo.phone_number.replace(/\D/g, '')}`;

  return (
    <Link
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 h-16 w-16 z-50 transition-transform hover:scale-110"
      aria-label="Chat on WhatsApp"
    >
      <Image 
        src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg"
        alt="WhatsApp Icon"
        fill
        className="object-contain"
      />
    </Link>
  );
}
